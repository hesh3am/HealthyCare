package com.example.quiz;

public class Database {
    Integer[] flags={
            R.drawable.up,
            R.drawable.down,
            R.drawable.left,
            R.drawable.right,
            R.drawable.up,
            R.drawable.down,
            R.drawable.left,
            R.drawable.right,
            R.drawable.up
    };
    String[] answers={
            "Up",
            "Down",
            "Left",
            "Right",
            "Up",
            "Down",
            "Left",
            "Right",
            "Up"
    };

}
